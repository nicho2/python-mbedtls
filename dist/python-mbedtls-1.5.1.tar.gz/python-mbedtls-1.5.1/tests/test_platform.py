import mbedtls._platform as _plt


def test_platform():
    _plt.__self_test()
