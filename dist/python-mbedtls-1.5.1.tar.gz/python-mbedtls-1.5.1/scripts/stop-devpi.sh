#!/bin/sh

set -ex

devpi-server --stop
